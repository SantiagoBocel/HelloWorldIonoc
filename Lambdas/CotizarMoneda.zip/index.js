const fetch = require('node-fetch');
exports.handler = async (event) => {
  let ammount;
  let operacion
  try {
      let Primero = event.Primero;
      let Segundo = event.Segundo;
      let combinacion = Primero + Segundo;
      let url 
      switch (combinacion) {
        case 'BTCUSDT':
          url = "https://api.binance.com/api/v3/ticker/price?symbol=BTCUSDT";
          operacion = true;
          break;
        case 'USDTBTC':
          url = "https://api.binance.com/api/v3/ticker/price?symbol=BTCUSDT";
          operacion = false;
          break;
          case 'BNBBTC':
          url = "https://api.binance.com/api/v3/ticker/price?symbol=BNBBTC";
          operacion = true;
          break;
        case 'BTCBNB':
          url = "https://api.binance.com/api/v3/ticker/price?symbol=BNBBTC";
          operacion = false;
          break;
          case 'ETHBTC':
          url = "https://api.binance.com/api/v3/ticker/price?symbol=ETHBTC";
          operacion = true;
          break;
          case 'BTCETH':
          url = "https://api.binance.com/api/v3/ticker/price?symbol=ETHBTC";
          operacion = false;
          break;
           case 'BNBETH':
          url = "https://api.binance.com/api/v3/ticker/price?symbol=BNBETH";
          operacion = true;
          break;
           case 'ETHBNB':
          url = "https://api.binance.com/api/v3/ticker/price?symbol=BNBETH";
          operacion = false;
          break;
          case 'BNBUSDT':
          url = "https://api.binance.com/api/v3/ticker/price?symbol=BNBUSDT";
          operacion = true;
          case 'USDTBNB':
          url = "https://api.binance.com/api/v3/ticker/price?symbol=BNBUSDT";
          operacion = false;
           case 'ETHUSDT':
          url = "https://api.binance.com/api/v3/ticker/price?symbol=ETHUSDT";
          operacion = true;
          case 'USDTETH':
          url = "https://api.binance.com/api/v3/ticker/price?symbol=ETHUSDT";
          operacion = false;
          break;
        default:
          // code
      }
      const bitcoinValue = await fetch(url)
      .then((data)=> data.json());
      ammount = await bitcoinValue["price"];
  } catch (error) {console.log(error);
  }
  let bitcoincount =ammount;
  let price 
  if (operacion) {
    price  =(event.Moneda * bitcoincount).toFixed(8);
  }
  else{
    price =(event.Moneda / bitcoincount).toFixed(8);
  }
  const returned = await{
      statusCode: 200,
      headers:{
          "Access-Control-Allow-Headers":"*",
          "Access-Control-Allow-Origin":"*",
          "Access-Control-Allow-Methods":"POST"
      },
      body:price,
      exchange:bitcoincount
  }
  return returned;
};

