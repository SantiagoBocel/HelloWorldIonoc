const {v4: uuidv4} = require('uuid');
const AWS = require('aws-sdk');
AWS.config.update({region:'us-east-2'})
const docClient = new AWS.DynamoDB.DocumentClient()

exports.handler=(event,context,callback)=>{
     let uuid_dato =uuidv4()
    var params={
        TableName:"Tabla_Compras",
        Item:{
           "uuid":uuid_dato,
           "uuid_Cotizacion":event.id_Cotizador,
           "TimeStamp":event.tiempo,
           "Usuario":event.usuario,
           "Tipo_Cambio":event.cambio,
           "MonedaDestino":event.CoinDest,
           "Cantidad_Original":event.cantidad,
           " Cantidad_Moneda_Comprada":event.resultado,
           "UsuarioIP":event.Usuarioip, 
           "Browser":event.browser,
           "Device":event.divice,
           "Geolocalizacion":event.geolocalizacion
        },
        headers:{
          "Access-Control-Allow-Headers":"Content-Type",
          "Access-Control-Allow-Origin":"*",
          "Access-Control-Allow-Methods":"POST"
      },
    };
     docClient.put(params,function(err,data){
        if(err){
            callback(err,null);
        }else{
            callback(null,uuid_dato)
        }
    });
}