const {v4: uuidv4} = require('uuid');
const AWS = require('aws-sdk');
AWS.config.update({region:'us-east-2'})
const docClient = new AWS.DynamoDB.DocumentClient()

exports.handler= async(event,context,callback)=>{
     let uuid_dato =uuidv4()
    var params={
        TableName:"Tabla_Compras",
        Item:{
           "uuid":uuid_dato,
           "uuid_Cotizacion":event.id_Cotizador,
           "TimeStamp":event.tiempo,
           "Usuario":event.usuario,
           "Tipo_Cambio":event.cambio,
           "MonedaOriginal":event.CoinOrg,
           "MonedaDestino":event.CoinDest,
           "Cantidad_Original":event.cantidad,
           " Cantidad_Moneda_Comprada":event.resultado,
           "UsuarioIP":event.Usuarioip, 
           "Browser":event.browser,
           "Device":event.divice,
           "Geolocalizacion":event.geolocalizacion
        },
        headers:{
          "Access-Control-Allow-Headers":"Content-Type",
          "Access-Control-Allow-Origin":"*",
          "Access-Control-Allow-Methods":"POST"
      },
    };
      try {
       await docClient.put(params).promise();
        return{ "uuid_Cotizar":uuid_dato}
    } catch (err) {return err}
}