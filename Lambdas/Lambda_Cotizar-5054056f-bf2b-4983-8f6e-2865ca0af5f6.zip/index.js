const {v4: uuidv4} = require('uuid');
const AWS = require('aws-sdk');
AWS.config.update({region:'us-east-2'})
const docClient = new AWS.DynamoDB.DocumentClient()
exports.handler= async(event,context,callback)=>{
    let uuid_dato =uuidv4()
    var params={
        TableName:"Tabla_Cotizaciones",
        Item:{
           "uuid": uuid_dato,
           "Usuario":event.usuario,
           "CantidadOriginal":event.cantidad,
           " Cantidad_Moneda_Cotizada":event.resultado,
           "MonedaOriginal":event.CoinOrg,
           "MonedaDestino":event.CoinDest,
           "UsuarioIP":event.Usuarioip, 
           "Browser":event.browser,
           "Device":event.divice,
           "TimeStamp":event.tiempo,
           "Geolocalizacion":event.geolocalizacion
        }
    };
    try {
       await docClient.put(params).promise();
        return{ "uuid_Cotizar":uuid_dato}
    } catch (err) {return err}
        
}