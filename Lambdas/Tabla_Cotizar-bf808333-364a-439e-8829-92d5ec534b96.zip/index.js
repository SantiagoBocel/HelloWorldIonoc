const AWS = require('aws-sdk');
AWS.config.update({region:'us-east-2'});
const ddb = new AWS.DynamoDB.DocumentClient();
 exports.handler = async (event,context,callback)=>{
    let params ={
        TableName: "Tabla_Compras",
          headers:{
          "Access-Control-Allow-Headers":"*",
          "Access-Control-Allow-Origin":"*",
          "Access-Control-Allow-Methods":"*"
        },
        Key:{
            "uuid":event.Id
        }
    };
    let body ;
    try{
    body= await ddb.get(params).promise();
    }catch(error){
        console.error(error);
    }
	return JSON.stringify(body)
};